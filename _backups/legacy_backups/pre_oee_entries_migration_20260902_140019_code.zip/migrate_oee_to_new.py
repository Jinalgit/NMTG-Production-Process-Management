"""
OEE Migration Script v1
=======================
Migrates historical data from old OEE tables:
  oee_entries + oee_entry_losses
into the new OEE tables:
  oee_machine_sessions + oee_machine_runs + oee_machine_loss_events

Grouping logic:
  Each unique (machine_id, entry_date, shift_name) from oee_entries
  becomes ONE oee_machine_sessions record.

  Each oee_entries row becomes ONE oee_machine_runs row
  (run_status = COMPLETED, historical).

  Each oee_entry_losses row becomes ONE oee_machine_loss_events row.

  Session-level OEE (ar_ratio, pr_ratio, qr_ratio, oee_ratio) is
  recomputed from the aggregated run quantities and loss totals,
  so the new system's formula is applied consistently.

HOW TO RUN:
  1. Copy this file to D:\\Het\\demo2\\migrate_oee_to_new.py
  2. First run in dry-run mode (default):
       python migrate_oee_to_new.py
     Review the printed output carefully.
  3. When satisfied, change DRY_RUN = False at the top and run again.
  4. After successful migration, run verification queries (printed at end).

SAFE GUARDS:
  - DRY_RUN = True by default (no DB writes).
  - If a session already exists for (machine_id, entry_date, shift_name),
    that group is SKIPPED with a warning (avoids duplicating test data).
  - Full rollback on any error.
  - Old tables are NOT dropped by this script. Drop manually after verification.
"""

import sys
import os
from collections import defaultdict

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------

DRY_RUN = False          # Set False to commit. Default True = safe read-only.
SYSTEM_USER_ID   = 1    # User ID to attribute migrated records to (admin)
SYSTEM_USER_NAME = "OEE-Migration-v1"

# ---------------------------------------------------------------------------
# Bootstrap: add demo2 root to path so we can import db
# ---------------------------------------------------------------------------

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

# Load .env (same logic as app.py)
_env_path = os.path.join(SCRIPT_DIR, ".env")
if os.path.exists(_env_path):
    with open(_env_path) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())

import db


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def _f(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _i(v):
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


def _recompute_session_oee(planned_min, ar_loss, pr_loss, run_min,
                            total_ok, total_rej, total_hold,
                            ideal_cycle_min):
    """
    Re-apply the CONFIRMED Excel OEE formula at session level.
    Returns dict with all computed KPIs.
    """
    total_qty = total_ok + total_rej + total_hold
    utilization = max(planned_min - ar_loss, 0.0)
    after_pr    = max(utilization - pr_loss,  0.0)

    ar_ratio  = utilization / planned_min if planned_min else 0.0
    pr_ratio  = run_min     / after_pr    if after_pr    else 0.0
    qr_ratio  = total_ok    / total_qty   if total_qty   else 0.0
    oee_ratio = ar_ratio * pr_ratio * qr_ratio

    # PLVA: only meaningful when ONE JC in the session
    target_qty     = None
    plan_vs_actual = None
    if ideal_cycle_min and ideal_cycle_min > 0:
        target_min     = max(planned_min - ar_loss, 0.0)   # same as PLVA_FIX_V1
        target_qty     = target_min / ideal_cycle_min
        if target_qty > 0:
            plan_vs_actual = total_qty / target_qty

    return {
        "utilization_minutes":    utilization,
        "after_pr_minutes":       after_pr,
        "total_ar_loss_minutes":  ar_loss,
        "total_pr_loss_minutes":  pr_loss,
        "ar_ratio":               ar_ratio,
        "pr_ratio":               pr_ratio,
        "qr_ratio":               qr_ratio,
        "oee_ratio":              oee_ratio,
        "target_qty":             target_qty,
        "plan_vs_actual":         plan_vs_actual,
    }


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    print("=" * 60)
    print("OEE MIGRATION SCRIPT v1")
    print(f"Mode: {'DRY RUN (no writes)' if DRY_RUN else '>>> LIVE — WILL WRITE TO DB <<<'}")
    print("=" * 60)

    conn   = db.get_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        # ------------------------------------------------------------------
        # STEP 1: Read oee_entries
        # ------------------------------------------------------------------
        print("\n[1] Reading oee_entries ...")

        cursor.execute("""
            SELECT *
            FROM oee_entries
            WHERE LOWER(TRIM(COALESCE(record_status, 'active')))
                  NOT IN ('deleted', 'cancelled', 'undone')
            ORDER BY machine_id, entry_date, shift_name, id
        """)
        entries = cursor.fetchall()
        print(f"    Found {len(entries)} entries.")

        if not entries:
            print("    Nothing to migrate. Exiting.")
            return

        # Detect JC column name
        sample    = entries[0]
        all_cols  = list(sample.keys())
        jc_col    = next(
            (c for c in ('jc_no', 'job_card_no', 'jc_number', 'jc')
             if c in all_cols),
            None
        )
        if not jc_col:
            print(f"ERROR: Cannot detect JC number column. Available: {all_cols}")
            return
        print(f"    JC column detected  : {jc_col}")

        # Detect cycle-time columns (may be stored or may be absent in old table)
        has_cycle = 'cycle_minutes'      in all_cols
        has_lu    = 'load_unload_minutes' in all_cols
        has_times = 'oee_start_time'     in all_cols
        has_ar    = 'ar_loss'            in all_cols   # pre-computed column
        has_pr    = 'pr_loss'            in all_cols
        print(f"    cycle cols present  : {has_cycle}")
        print(f"    load/unload present : {has_lu}")
        print(f"    oee times present   : {has_times}")
        print(f"    ar_loss col present : {has_ar}")

        # ------------------------------------------------------------------
        # STEP 2: Read all losses, keyed by oee_entry_id
        # ------------------------------------------------------------------
        print("\n[2] Reading oee_entry_losses ...")
        cursor.execute("""
            SELECT *
            FROM oee_entry_losses
            ORDER BY oee_entry_id, id
        """)
        loss_rows = cursor.fetchall()
        print(f"    Found {len(loss_rows)} loss events.")

        losses_by_entry = defaultdict(list)
        for lr in loss_rows:
            losses_by_entry[lr['oee_entry_id']].append(lr)

        # ------------------------------------------------------------------
        # STEP 3: Read oee_loss_types for ID mapping
        # ------------------------------------------------------------------
        print("\n[3] Reading oee_loss_types ...")
        cursor.execute("SELECT id, loss_code FROM oee_loss_types")
        loss_type_map = {
            str(r['loss_code']).strip().upper(): r['id']
            for r in cursor.fetchall()
        }
        print(f"    {len(loss_type_map)} loss types loaded.")

        # ------------------------------------------------------------------
        # STEP 4: Group entries by session key
        # ------------------------------------------------------------------
        print("\n[4] Grouping entries by (machine_id, entry_date, shift_name) ...")

        groups = defaultdict(list)
        for e in entries:
            mid   = e.get('machine_id')
            edate = str(e.get('entry_date') or '')[:10]
            shift = (e.get('shift_name') or '').strip()
            if not mid or not edate:
                continue
            groups[(mid, edate, shift)].append(e)

        print(f"    {len(groups)} unique sessions will be created.")

        # ------------------------------------------------------------------
        # STEP 5: Check for already-existing sessions
        # ------------------------------------------------------------------
        print("\n[5] Checking for sessions that already exist in new system ...")
        cursor.execute("""
            SELECT machine_id,
                   DATE_FORMAT(session_date, '%%Y-%%m-%%d') AS session_date,
                   TRIM(shift_name) AS shift_name
            FROM oee_machine_sessions
        """)
        existing_sessions = set(
            (r['machine_id'], r['session_date'], (r['shift_name'] or '').strip())
            for r in cursor.fetchall()
        )
        if existing_sessions:
            print(f"    WARNING: {len(existing_sessions)} existing sessions found.")
            print("    Groups that collide will be SKIPPED to avoid duplicates.")
        else:
            print("    No collisions — all groups are new.")

        # ------------------------------------------------------------------
        # STEP 6: Migrate
        # ------------------------------------------------------------------
        print("\n[6] Running migration ...")
        stats = {
            'sessions_created': 0,
            'sessions_skipped': 0,
            'runs_created':     0,
            'losses_created':   0,
            'entries_skipped':  0,
        }

        for (machine_id, edate, shift), group_entries in sorted(groups.items()):

            # --- Collision check ---
            if (machine_id, edate, shift) in existing_sessions:
                print(f"  SKIP (already exists) machine={machine_id} date={edate} shift={shift!r}")
                stats['sessions_skipped'] += 1
                stats['entries_skipped']  += len(group_entries)
                continue

            # ------------------------------------------------------------------
            # Aggregate session-level totals from all entries in this group
            # ------------------------------------------------------------------
            planned_min  = _f(group_entries[0].get('planned_minutes') or 480)

            total_ok      = sum(_i(e.get('ok_qty'))       for e in group_entries)
            total_rej     = sum(_i(e.get('rejected_qty')) for e in group_entries)
            total_hold    = sum(_i(e.get('hold_qty'))     for e in group_entries)
            total_run_min = sum(_f(e.get('run_minutes'))  for e in group_entries)

            # AR / PR loss from oee_entry_losses (by loss_category_snapshot)
            group_entry_ids = {e['id'] for e in group_entries}
            ar_loss = 0.0
            pr_loss = 0.0
            for lr in loss_rows:
                if lr['oee_entry_id'] not in group_entry_ids:
                    continue
                cat = str(lr.get('loss_category_snapshot') or '').strip().upper()
                min_ = _f(lr.get('loss_minutes'))
                if cat == 'AR':
                    ar_loss += min_
                elif cat == 'PR':
                    pr_loss += min_

            # If old table pre-computes AR/PR loss use those when losses not found
            if ar_loss == 0.0 and has_ar and len(group_entries) == 1:
                ar_loss = _f(group_entries[0].get('ar_loss'))
            if pr_loss == 0.0 and has_pr and len(group_entries) == 1:
                pr_loss = _f(group_entries[0].get('pr_loss'))

            # Ideal cycle time — only meaningful for single-JC sessions
            ideal_cycle_min = 0.0
            if len(group_entries) == 1:
                e = group_entries[0]
                cm = _i(e.get('cycle_minutes')       if has_cycle else 0)
                cs = _i(e.get('cycle_seconds')       if has_cycle else 0)
                lm = _i(e.get('load_unload_minutes') if has_lu    else 0)
                ls = _i(e.get('load_unload_seconds') if has_lu    else 0)
                ideal_cycle_min = cm + cs / 60.0 + lm + ls / 60.0

            # Recompute session OEE with the PLVA_FIX_V1 formula
            kpi = _recompute_session_oee(
                planned_min, ar_loss, pr_loss, total_run_min,
                total_ok, total_rej, total_hold, ideal_cycle_min
            )

            # ------------------------------------------------------------------
            # CREATE SESSION
            # ------------------------------------------------------------------
            print(f"\n  SESSION machine={machine_id} date={edate} shift={shift!r}")
            print(f"    planned={planned_min:.0f}min ok={total_ok} rej={total_rej} "
                  f"ar_loss={ar_loss:.0f} oee={kpi['oee_ratio']:.2%}")

            if DRY_RUN:
                new_session_id = f"DRY_{machine_id}_{edate}_{shift}"
                print(f"    [DRY] Would INSERT session")
            else:
                cursor.execute("""
                    INSERT INTO oee_machine_sessions (
                        machine_id,
                        session_date,
                        shift_name,
                        session_status,
                        planned_minutes,

                        total_ok_qty,
                        total_rejected_qty,
                        total_hold_qty,
                        total_run_minutes,

                        total_ar_loss_minutes,
                        total_pr_loss_minutes,
                        utilization_minutes,
                        after_pr_minutes,

                        target_qty,
                        plan_vs_actual,

                        ar_ratio,
                        pr_ratio,
                        qr_ratio,
                        oee_ratio,

                        opened_by_user_id,
                        opened_by_name,
                        started_at
                    ) VALUES (
                        %s, %s, %s, 'CLOSED', %s,
                        %s, %s, %s, %s,
                        %s, %s, %s, %s,
                        %s, %s,
                        %s, %s, %s, %s,
                        %s, %s, %s
                    )
                """, (
                    machine_id, edate, shift, planned_min,
                    total_ok, total_rej, total_hold, total_run_min,
                    ar_loss, pr_loss,
                    kpi['utilization_minutes'], kpi['after_pr_minutes'],
                    kpi['target_qty'], kpi['plan_vs_actual'],
                    kpi['ar_ratio'], kpi['pr_ratio'], kpi['qr_ratio'], kpi['oee_ratio'],
                    SYSTEM_USER_ID, SYSTEM_USER_NAME, edate,
                ))
                new_session_id = cursor.lastrowid
                stats['sessions_created'] += 1
                print(f"    Created session id={new_session_id}")

            # ------------------------------------------------------------------
            # CREATE RUNS + LOSSES
            # ------------------------------------------------------------------
            for entry in group_entries:
                jc_no       = str(entry.get(jc_col) or '').strip()
                process     = entry.get('process_name') or ''
                ok_q        = _i(entry.get('ok_qty'))
                rej_q       = _i(entry.get('rejected_qty'))
                hold_q      = _i(entry.get('hold_qty'))
                run_m       = _f(entry.get('run_minutes'))
                oee_start   = entry.get('oee_start_time') if has_times else None
                oee_end     = entry.get('oee_end_time')   if has_times else None
                c_min       = _i(entry.get('cycle_minutes')       if has_cycle else 0)
                c_sec       = _i(entry.get('cycle_seconds')       if has_cycle else 0)
                lu_min      = _i(entry.get('load_unload_minutes') if has_lu    else 0)
                lu_sec      = _i(entry.get('load_unload_seconds') if has_lu    else 0)
                op_name     = entry.get('operator_name') or SYSTEM_USER_NAME

                print(f"    RUN JC={jc_no} ok={ok_q} rej={rej_q} hold={hold_q}")

                if DRY_RUN:
                    new_run_id = f"DRY_{entry['id']}"
                    print(f"      [DRY] Would INSERT run")
                else:
                    cursor.execute("""
                        INSERT INTO oee_machine_runs (
                            session_id,
                            machine_id,
                            operator_user_id,
                            operator_name,
                            job_card_no,
                            process_name,
                            run_status,
                            started_at,
                            oee_start_time,
                            oee_end_time,
                            cycle_minutes,
                            cycle_seconds,
                            load_unload_minutes,
                            load_unload_seconds,
                            ok_qty,
                            rejected_qty,
                            hold_qty,
                            updated_at
                        ) VALUES (
                            %s, %s, %s, %s, %s, %s,
                            'COMPLETED',
                            %s, %s, %s,
                            %s, %s, %s, %s,
                            %s, %s, %s,
                            NOW()
                        )
                    """, (
                        new_session_id, machine_id,
                        SYSTEM_USER_ID, op_name,
                        jc_no, process,
                        edate, oee_start, oee_end,
                        c_min, c_sec, lu_min, lu_sec,
                        ok_q, rej_q, hold_q,
                    ))
                    new_run_id = cursor.lastrowid
                    stats['runs_created'] += 1

                # Losses for this entry
                entry_losses = losses_by_entry.get(entry['id'], [])
                for lr in entry_losses:
                    code = str(lr.get('loss_code_snapshot') or '').strip().upper()
                    if not code:
                        continue
                    loss_name    = lr.get('loss_name_snapshot') or code
                    loss_minutes = _f(lr.get('loss_minutes'))
                    loss_type_id = loss_type_map.get(code)

                    if DRY_RUN:
                        print(f"      [DRY] Would INSERT loss: {code} {loss_minutes}min")
                    else:
                        cursor.execute("""
                            INSERT INTO oee_machine_loss_events (
                                session_id,
                                run_id,
                                machine_id,
                                loss_type_id,
                                loss_code,
                                loss_name,
                                loss_minutes
                            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                        """, (
                            new_session_id,
                            new_run_id,
                            machine_id,
                            loss_type_id,
                            code,
                            loss_name,
                            loss_minutes,
                        ))
                        stats['losses_created'] += 1

        # ------------------------------------------------------------------
        # COMMIT or ROLLBACK
        # ------------------------------------------------------------------
        if DRY_RUN:
            conn.rollback()
            print("\n" + "=" * 60)
            print("DRY RUN COMPLETE — zero rows written.")
            print("If the above output looks correct:")
            print("  Set DRY_RUN = False and run again.")
            print("=" * 60)
        else:
            conn.commit()
            print("\n" + "=" * 60)
            print("MIGRATION COMPLETE")
            print(f"  Sessions created : {stats['sessions_created']}")
            print(f"  Sessions skipped : {stats['sessions_skipped']}")
            print(f"  Runs created     : {stats['runs_created']}")
            print(f"  Loss events      : {stats['losses_created']}")
            print(f"  Entries skipped  : {stats['entries_skipped']}")
            print("=" * 60)

            # Verification queries to run in MySQL
            print("""
VERIFICATION — run these in MySQL CLI to confirm:

SELECT COUNT(*) FROM oee_machine_sessions
  WHERE opened_by_name = 'OEE-Migration-v1';

SELECT COUNT(*) FROM oee_machine_runs
  WHERE operator_name = 'OEE-Migration-v1';

SELECT COUNT(*) FROM oee_machine_loss_events mle
  JOIN oee_machine_runs mr ON mr.id = mle.run_id
  WHERE mr.operator_name = 'OEE-Migration-v1';

-- Cross-check entry counts:
SELECT COUNT(*) FROM oee_entries
  WHERE LOWER(TRIM(COALESCE(record_status,'active')))
        NOT IN ('deleted','cancelled','undone');
""")

    except Exception as exc:
        conn.rollback()
        print(f"\nERROR: {exc}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    finally:
        cursor.close()
        conn.close()


if __name__ == "__main__":
    main()
