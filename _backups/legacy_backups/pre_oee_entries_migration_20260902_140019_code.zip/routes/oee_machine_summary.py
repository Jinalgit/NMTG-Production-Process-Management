"""
OEE Summary — reads from the NEW OEE tables.

Access:
    Admin, Supervisor, Operator (Operator sees table only, no export)

Live-data mode:
    Metrics are computed directly from oee_machine_runs (COMPLETED runs)
    and oee_machine_loss_events, so OPEN sessions with in-flight data
    show up immediately without waiting for the operator to close.

Routes:
    GET  /oee-machine-summary                              — page
    GET  /api/oee-machine-summary/kpi                      — KPI strip totals
    GET  /api/oee-machine-summary/machine-wise             — machine table
    GET  /api/oee-machine-summary/operator-wise            — operator table
    GET  /api/oee-machine-summary/drill-down               — sessions + losses for one row
    GET  /api/oee-machine-summary/filters                  — zone / machine / operator lists

Read-only: no INSERT / UPDATE / DELETE anywhere.
"""

import json
from datetime import date, datetime, timedelta

from flask import (
    Blueprint,
    Response,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from db import get_connection


oee_machine_summary_bp = Blueprint("oee_machine_summary", __name__)


# ============================================================
# HELPERS
# ============================================================

def _jsonify(data, status=200):
    return Response(
        json.dumps(data, ensure_ascii=False, default=str),
        status=status,
        content_type="application/json; charset=utf-8",
    )


def _f(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _int(v):
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


def _ratio(numerator, denominator):
    d = _f(denominator)
    return _f(numerator) / d if d else 0.0


def _pct(x):
    return round(_f(x) * 100.0, 1)


def _access_role():
    role = (session.get("role") or "").strip().lower()
    if role not in ("admin", "supervisor", "operator"):
        raise PermissionError(
            "OEE Summary is available to Admin, Supervisor and Operator only."
        )
    return role


def _can_export(role):
    return role in ("admin", "supervisor")


# ---- date helpers ------------------------------------------------

def _today():
    return date.today()


def _resolve_preset(preset):
    t = _today()
    p = (preset or "").strip().lower()

    if p == "today":
        return t, t
    if p == "yesterday":
        y = t - timedelta(days=1)
        return y, y
    if p == "this_week":
        start = t - timedelta(days=t.weekday())
        return start, t
    if p == "last_week":
        this_start = t - timedelta(days=t.weekday())
        last_end   = this_start - timedelta(days=1)
        last_start = last_end - timedelta(days=6)
        return last_start, last_end
    if p == "this_month":
        return t.replace(day=1), t
    if p == "last_month":
        first_this = t.replace(day=1)
        last_month_end = first_this - timedelta(days=1)
        last_month_start = last_month_end.replace(day=1)
        return last_month_start, last_month_end
    return None, None


def _parse_dates():
    fmt = "%Y-%m-%d"
    fd_s = (request.args.get("from_date") or "").strip()
    td_s = (request.args.get("to_date")   or "").strip()

    fd = td = None
    try:
        if fd_s:
            fd = datetime.strptime(fd_s, fmt).date()
    except ValueError:
        fd = None
    try:
        if td_s:
            td = datetime.strptime(td_s, fmt).date()
    except ValueError:
        td = None

    if not fd and not td:
        p_fd, p_td = _resolve_preset(request.args.get("preset"))
        if p_fd:
            fd, td = p_fd, p_td

    if fd and not td:
        td = fd
    if td and not fd:
        fd = td

    if not fd or not td:
        t = _today()
        fd = t.replace(day=1)
        td = t

    if fd > td:
        fd, td = td, fd

    return fd, td


def _optional_filters():
    zone = (request.args.get("zone") or "").strip() or None

    mid_s = (request.args.get("machine_id") or "").strip()
    machine_id = None
    if mid_s:
        try:
            machine_id = int(mid_s)
        except ValueError:
            machine_id = None

    oid_s = (request.args.get("operator_master_id") or "").strip()
    operator_master_id = None
    if oid_s:
        try:
            operator_master_id = int(oid_s)
        except ValueError:
            operator_master_id = None

    return zone, machine_id, operator_master_id


def _shift_display(name):
    if not name:
        return ""
    s = str(name).strip()

    if any(s.lower().endswith(sfx) for sfx in ("st", "nd", "rd", "th")):
        return s

    lower = s.lower()
    if lower.startswith("shift "):
        s = s[6:].strip()

    if s.isdigit():
        n = int(s)
        suffix = "th"
        if n % 100 not in (11, 12, 13):
            suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
        return f"{n}{suffix}"

    return name


def _oee_block(planned, ar_loss, pr_loss, run, ok, rej, hold, target_qty=None):
    """
    Live OEE computation:
        utilization = max(planned - ar_loss, 0)
        after_pr    = max(utilization - pr_loss, 0)
        AR = utilization / planned
        PR = run / after_pr
        QR = ok / total_qty
        OEE = AR * PR * QR
    """
    planned  = _f(planned)
    ar_loss  = _f(ar_loss)
    pr_loss  = _f(pr_loss)
    run      = _f(run)
    ok_v     = _f(ok)
    rej_v    = _f(rej)
    hold_v   = _f(hold)
    total_qty = ok_v + rej_v + hold_v

    utilization = max(planned - ar_loss, 0.0)
    after_pr    = max(utilization - pr_loss, 0.0)

    ar  = _ratio(utilization, planned)
    pr  = _ratio(run, after_pr)
    qr  = _ratio(ok_v, total_qty) if total_qty else 1.0
    oee = ar * pr * qr

    plan_vs_actual = None
    tq = _f(target_qty) if target_qty is not None else 0.0
    if tq > 0:
        plan_vs_actual = total_qty / tq

    return {
        "planned_minutes":     round(planned, 2),
        "utilization_minutes": round(utilization, 2),
        "after_pr_minutes":    round(after_pr, 2),
        "run_minutes":         round(run, 2),
        "ar_loss_minutes":     round(ar_loss, 2),
        "pr_loss_minutes":     round(pr_loss, 2),
        "ok_qty":              int(ok_v),
        "rejected_qty":        int(rej_v),
        "hold_qty":            int(hold_v),
        "total_qty":           int(total_qty),
        "target_qty":          round(tq, 2) if target_qty is not None else None,
        "plan_vs_actual":      round(plan_vs_actual, 4) if plan_vs_actual is not None else None,
        "planned_hours":       round(planned / 60.0, 2),
        "run_hours":           round(run / 60.0, 2),
        "ar":                  ar,
        "pr":                  pr,
        "qr":                  qr,
        "oee":                 oee,
        "ar_pct":              _pct(ar),
        "pr_pct":              _pct(pr),
        "qr_pct":              _pct(qr),
        "oee_pct":             _pct(oee),
    }


# ============================================================
# SHARED SQL FRAGMENTS
# ============================================================

# Planned minutes per run — end - start, wrapped over midnight
_PLANNED_PER_RUN_SQL = """
    CASE
        WHEN r.oee_start_time IS NULL OR r.oee_end_time IS NULL THEN 0
        WHEN TIME_TO_SEC(r.oee_end_time) >= TIME_TO_SEC(r.oee_start_time)
             THEN (TIME_TO_SEC(r.oee_end_time) - TIME_TO_SEC(r.oee_start_time)) / 60.0
        ELSE (TIME_TO_SEC(r.oee_end_time) - TIME_TO_SEC(r.oee_start_time) + 86400) / 60.0
    END
"""

# Run minutes per run = ok_qty * ideal_cycle_time (min)
_RUN_MIN_PER_RUN_SQL = """
    r.ok_qty * (
        r.cycle_minutes + r.cycle_seconds / 60.0 +
        r.load_unload_minutes + r.load_unload_seconds / 60.0
    )
"""


# ============================================================
# PAGE ROUTE
# ============================================================

@oee_machine_summary_bp.route("/oee-machine-summary")
def oee_machine_summary_page():
    role = (session.get("role") or "").strip().lower()
    if role not in ("admin", "supervisor", "operator"):
        return redirect(url_for("auth.login"))

    return render_template(
        "oee_machine_summary.html",
        active_page="oee_machine_summary",
        can_export=_can_export(role),
    )


# ============================================================
# API — FILTER DROPDOWNS
# ============================================================

@oee_machine_summary_bp.route("/api/oee-machine-summary/filters")
def api_oee_machine_summary_filters():
    try:
        _access_role()

        conn = get_connection()
        cur  = conn.cursor(dictionary=True)

        cur.execute(
            """
            SELECT DISTINCT zone
            FROM oee_machines
            WHERE is_active = 1
              AND zone IS NOT NULL
              AND TRIM(zone) <> ''
            ORDER BY zone
            """
        )
        zones = [r["zone"] for r in cur.fetchall()]

        cur.execute(
            """
            SELECT id, machine_no, machine_name, zone, machine_category
            FROM oee_machines
            WHERE is_active = 1
            ORDER BY machine_no
            """
        )
        machines = cur.fetchall()

        cur.execute(
            """
            SELECT id, employee_no, operator_name
            FROM oee_operator_master
            WHERE is_active = 1
            ORDER BY CAST(employee_no AS UNSIGNED), employee_no
            """
        )
        operators = cur.fetchall()

        cur.close()
        conn.close()

        return _jsonify({
            "zones":     zones,
            "machines":  machines,
            "operators": operators,
        })

    except PermissionError as exc:
        return _jsonify({"error": str(exc)}, 403)
    except Exception as exc:
        import traceback
        return _jsonify({"error": str(exc), "trace": traceback.format_exc()}, 500)


# ============================================================
# API — KPI STRIP
# ============================================================

@oee_machine_summary_bp.route("/api/oee-machine-summary/kpi")
def api_oee_machine_summary_kpi():
    try:
        _access_role()

        fd, td = _parse_dates()
        zone, machine_id, _ = _optional_filters()

        conn = get_connection()
        cur  = conn.cursor(dictionary=True)

        # -------- runs aggregation --------
        r_where = [
            "s.session_date BETWEEN %s AND %s",
            "r.run_status = 'COMPLETED'",
        ]
        r_params = [str(fd), str(td)]
        if zone:
            r_where.append("m.zone = %s")
            r_params.append(zone)
        if machine_id:
            r_where.append("r.machine_id = %s")
            r_params.append(machine_id)

        cur.execute(
            f"""
            SELECT
                COUNT(DISTINCT r.machine_id)             AS active_machines,
                COUNT(DISTINCT r.session_id)             AS total_sessions,
                COALESCE(SUM(r.ok_qty), 0)               AS ok_qty,
                COALESCE(SUM(r.rejected_qty), 0)         AS rej_qty,
                COALESCE(SUM(r.hold_qty), 0)             AS hold_qty,
                COALESCE(SUM({_PLANNED_PER_RUN_SQL}), 0) AS planned_min,
                COALESCE(SUM({_RUN_MIN_PER_RUN_SQL}), 0) AS run_min
            FROM oee_machine_runs r
            JOIN oee_machine_sessions s ON s.id = r.session_id
            JOIN oee_machines m         ON m.id = r.machine_id
            WHERE {' AND '.join(r_where)}
            """,
            r_params,
        )
        run_agg = cur.fetchone() or {}

        # -------- losses aggregation (AR / PR) --------
        l_where = [
            "s.session_date BETWEEN %s AND %s",
        ]
        l_params = [str(fd), str(td)]
        if zone:
            l_where.append("m.zone = %s")
            l_params.append(zone)
        if machine_id:
            l_where.append("le.machine_id = %s")
            l_params.append(machine_id)

        cur.execute(
            f"""
            SELECT
                COALESCE(lt.loss_category, 'AR') AS loss_category,
                COALESCE(SUM(le.loss_minutes), 0) AS total_min
            FROM oee_machine_loss_events le
            JOIN oee_machine_sessions s ON s.id = le.session_id
            JOIN oee_machines m         ON m.id = le.machine_id
            LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
            WHERE {' AND '.join(l_where)}
            GROUP BY COALESCE(lt.loss_category, 'AR')
            """,
            l_params,
        )
        ar_loss = pr_loss = 0.0
        for r in cur.fetchall():
            cat = (r["loss_category"] or "AR").upper()
            if cat == "PR":
                pr_loss = _f(r["total_min"])
            else:
                ar_loss = _f(r["total_min"])

        cur.execute(
            "SELECT COUNT(*) AS c FROM oee_machines WHERE is_active = 1"
        )
        total_machines = _int((cur.fetchone() or {}).get("c"))

        cur.close()
        conn.close()

        block = _oee_block(
            planned=run_agg.get("planned_min"),
            ar_loss=ar_loss,
            pr_loss=pr_loss,
            run=run_agg.get("run_min"),
            ok=run_agg.get("ok_qty"),
            rej=run_agg.get("rej_qty"),
            hold=run_agg.get("hold_qty"),
        )

        loss_hours = (ar_loss + pr_loss) / 60.0

        kpi = {
            "period":          {"from_date": str(fd), "to_date": str(td)},
            "total_machines":  total_machines,
            "active_machines": _int(run_agg.get("active_machines")),
            "total_sessions":  _int(run_agg.get("total_sessions")),
            "ok_qty":          block["ok_qty"],
            "rejected_qty":    block["rejected_qty"],
            "hold_qty":        block["hold_qty"],
            "total_qty":       block["total_qty"],
            "planned_hours":   block["planned_hours"],
            "run_hours":       block["run_hours"],
            "loss_hours":      round(loss_hours, 2),
            "ar_pct":          block["ar_pct"],
            "pr_pct":          block["pr_pct"],
            "qr_pct":          block["qr_pct"],
            "oee_pct":         block["oee_pct"],
        }

        return _jsonify(kpi)

    except PermissionError as exc:
        return _jsonify({"error": str(exc)}, 403)
    except Exception as exc:
        import traceback
        return _jsonify({"error": str(exc), "trace": traceback.format_exc()}, 500)


# ============================================================
# API — MACHINE-WISE
# ============================================================

@oee_machine_summary_bp.route("/api/oee-machine-summary/machine-wise")
def api_oee_machine_summary_machine_wise():
    try:
        _access_role()

        fd, td = _parse_dates()
        zone, machine_id, _ = _optional_filters()

        conn = get_connection()
        cur  = conn.cursor(dictionary=True)

        # -------- per-machine runs aggregation --------
        m_where = ["m.is_active = 1"]
        m_params = []
        if zone:
            m_where.append("m.zone = %s")
            m_params.append(zone)
        if machine_id:
            m_where.append("m.id = %s")
            m_params.append(machine_id)

        cur.execute(
            f"""
            SELECT
                m.id                                     AS machine_id,
                m.machine_no                             AS machine_no,
                m.machine_name                           AS machine_name,
                m.machine_category                       AS machine_category,
                m.zone                                   AS zone,
                COUNT(DISTINCT r.session_id)             AS session_count,
                COALESCE(SUM(r.ok_qty), 0)               AS ok_qty,
                COALESCE(SUM(r.rejected_qty), 0)         AS rejected_qty,
                COALESCE(SUM(r.hold_qty), 0)             AS hold_qty,
                COALESCE(SUM({_PLANNED_PER_RUN_SQL}), 0) AS planned_min,
                COALESCE(SUM({_RUN_MIN_PER_RUN_SQL}), 0) AS run_min
            FROM oee_machines m
            LEFT JOIN oee_machine_sessions s
                ON s.machine_id = m.id
               AND s.session_date BETWEEN %s AND %s
            LEFT JOIN oee_machine_runs r
                ON r.session_id = s.id
               AND r.run_status = 'COMPLETED'
            WHERE {' AND '.join(m_where)}
            GROUP BY
                m.id, m.machine_no, m.machine_name,
                m.machine_category, m.zone
            ORDER BY m.machine_no
            """,
            [str(fd), str(td)] + m_params,
        )
        base_rows = cur.fetchall()

        # -------- per-machine losses (AR / PR) --------
        l_where = [
            "s.session_date BETWEEN %s AND %s",
        ]
        l_params = [str(fd), str(td)]
        if zone:
            l_where.append("m.zone = %s")
            l_params.append(zone)
        if machine_id:
            l_where.append("le.machine_id = %s")
            l_params.append(machine_id)

        cur.execute(
            f"""
            SELECT
                le.machine_id                    AS machine_id,
                COALESCE(lt.loss_category, 'AR') AS loss_category,
                SUM(le.loss_minutes)             AS total_min
            FROM oee_machine_loss_events le
            JOIN oee_machine_sessions s ON s.id = le.session_id
            JOIN oee_machines m         ON m.id = le.machine_id
            LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
            WHERE {' AND '.join(l_where)}
            GROUP BY le.machine_id, COALESCE(lt.loss_category, 'AR')
            """,
            l_params,
        )
        loss_map = {}
        for lr in cur.fetchall():
            mid = lr["machine_id"]
            cat = (lr["loss_category"] or "AR").upper()
            loss_map.setdefault(mid, {"AR": 0.0, "PR": 0.0})
            loss_map[mid][cat] = _f(lr["total_min"])

        cur.close()
        conn.close()

        machines = []
        for r in base_rows:
            mid = r["machine_id"]
            ar_l = loss_map.get(mid, {}).get("AR", 0.0)
            pr_l = loss_map.get(mid, {}).get("PR", 0.0)

            blk = _oee_block(
                planned=r["planned_min"],
                ar_loss=ar_l,
                pr_loss=pr_l,
                run=r["run_min"],
                ok=r["ok_qty"],
                rej=r["rejected_qty"],
                hold=r["hold_qty"],
            )
            blk["machine_id"]       = mid
            blk["machine_no"]       = r["machine_no"]
            blk["machine_name"]     = r["machine_name"]
            blk["machine_category"] = r["machine_category"]
            blk["zone"]             = r["zone"]
            blk["session_count"]    = _int(r["session_count"])
            machines.append(blk)

        return _jsonify({
            "period":   {"from_date": str(fd), "to_date": str(td)},
            "machines": machines,
        })

    except PermissionError as exc:
        return _jsonify({"error": str(exc)}, 403)
    except Exception as exc:
        import traceback
        return _jsonify({"error": str(exc), "trace": traceback.format_exc()}, 500)


# ============================================================
# API — OPERATOR-WISE
# ============================================================

@oee_machine_summary_bp.route("/api/oee-machine-summary/operator-wise")
def api_oee_machine_summary_operator_wise():
    try:
        _access_role()

        fd, td = _parse_dates()
        zone, machine_id, operator_master_id = _optional_filters()

        conn = get_connection()
        cur  = conn.cursor(dictionary=True)

        r_where_in = [
            "s.session_date BETWEEN %s AND %s",
            "r.run_status = 'COMPLETED'",
        ]
        r_params = [str(fd), str(td)]

        if zone:
            r_where_in.append("m.zone = %s")
            r_params.append(zone)
        if machine_id:
            r_where_in.append("r.machine_id = %s")
            r_params.append(machine_id)
        if operator_master_id:
            r_where_in.append("o.id = %s")
            r_params.append(operator_master_id)

        where_op = ["o.is_active = 1"]
        params_op = []
        if operator_master_id:
            where_op.append("o.id = %s")
            params_op.append(operator_master_id)

        cur.execute(
            f"""
            SELECT
                o.id                                     AS operator_master_id,
                o.employee_no                            AS employee_no,
                o.operator_name                          AS operator_name,
                COUNT(DISTINCT r.session_id)             AS session_count,
                COUNT(r.id)                              AS run_count,
                COALESCE(SUM(r.ok_qty), 0)               AS ok_qty,
                COALESCE(SUM(r.rejected_qty), 0)         AS rejected_qty,
                COALESCE(SUM(r.hold_qty), 0)             AS hold_qty,
                COALESCE(SUM({_PLANNED_PER_RUN_SQL}), 0) AS planned_min,
                COALESCE(SUM({_RUN_MIN_PER_RUN_SQL}), 0) AS run_min
            FROM oee_operator_master o
            LEFT JOIN oee_machine_runs r
                ON r.operator_master_id = o.id
            LEFT JOIN oee_machine_sessions s
                ON s.id = r.session_id
            LEFT JOIN oee_machines m
                ON m.id = r.machine_id
            WHERE {' AND '.join(where_op)}
              AND (
                r.id IS NULL
                OR ({' AND '.join(r_where_in)})
              )
            GROUP BY o.id, o.employee_no, o.operator_name
            ORDER BY CAST(o.employee_no AS UNSIGNED), o.employee_no
            """,
            params_op + r_params,
        )
        base_rows = cur.fetchall()

        l_where = [
            "s.session_date BETWEEN %s AND %s",
            "le.operator_master_id IS NOT NULL",
        ]
        l_params = [str(fd), str(td)]

        if zone:
            l_where.append("m.zone = %s")
            l_params.append(zone)
        if machine_id:
            l_where.append("le.machine_id = %s")
            l_params.append(machine_id)
        if operator_master_id:
            l_where.append("le.operator_master_id = %s")
            l_params.append(operator_master_id)

        cur.execute(
            f"""
            SELECT
                le.operator_master_id            AS operator_master_id,
                COALESCE(lt.loss_category, 'AR') AS loss_category,
                SUM(le.loss_minutes)             AS total_min
            FROM oee_machine_loss_events le
            JOIN oee_machine_sessions s ON s.id = le.session_id
            LEFT JOIN oee_machines m    ON m.id = le.machine_id
            LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
            WHERE {' AND '.join(l_where)}
            GROUP BY le.operator_master_id, COALESCE(lt.loss_category, 'AR')
            """,
            l_params,
        )
        loss_map = {}
        for lr in cur.fetchall():
            oid = lr["operator_master_id"]
            cat = (lr["loss_category"] or "AR").upper()
            loss_map.setdefault(oid, {"AR": 0.0, "PR": 0.0})
            loss_map[oid][cat] = _f(lr["total_min"])

        cur.close()
        conn.close()

        operators = []
        for r in base_rows:
            oid = r["operator_master_id"]
            ar_l = loss_map.get(oid, {}).get("AR", 0.0)
            pr_l = loss_map.get(oid, {}).get("PR", 0.0)

            blk = _oee_block(
                planned=r["planned_min"],
                ar_loss=ar_l,
                pr_loss=pr_l,
                run=r["run_min"],
                ok=r["ok_qty"],
                rej=r["rejected_qty"],
                hold=r["hold_qty"],
            )
            blk["operator_master_id"] = oid
            blk["employee_no"]        = r["employee_no"]
            blk["operator_name"]      = r["operator_name"]
            blk["session_count"]      = _int(r["session_count"])
            blk["run_count"]          = _int(r["run_count"])
            operators.append(blk)

        return _jsonify({
            "period":    {"from_date": str(fd), "to_date": str(td)},
            "operators": operators,
        })

    except PermissionError as exc:
        return _jsonify({"error": str(exc)}, 403)
    except Exception as exc:
        import traceback
        return _jsonify({"error": str(exc), "trace": traceback.format_exc()}, 500)


# ============================================================
# API — DRILL-DOWN (sessions + top losses)
# ============================================================

@oee_machine_summary_bp.route("/api/oee-machine-summary/drill-down")
def api_oee_machine_summary_drill_down():
    try:
        _access_role()

        fd, td = _parse_dates()
        kind = (request.args.get("kind") or "").strip().lower()
        id_s = (request.args.get("id")   or "").strip()

        if kind not in ("machine", "operator"):
            return _jsonify({"error": "kind must be 'machine' or 'operator'"}, 400)

        try:
            row_id = int(id_s)
        except ValueError:
            return _jsonify({"error": "id must be an integer"}, 400)

        conn = get_connection()
        cur  = conn.cursor(dictionary=True)

        sessions = []
        top_losses = []

        if kind == "machine":
            # session-by-session aggregation from runs
            cur.execute(
                f"""
                SELECT
                    s.id                                     AS session_id,
                    s.session_date                           AS session_date,
                    s.shift_name                             AS shift_name,
                    s.session_status                         AS session_status,
                    s.opened_by_name                         AS opened_by_name,
                    COUNT(r.id)                              AS run_count,
                    COALESCE(SUM(r.ok_qty), 0)               AS ok_qty,
                    COALESCE(SUM(r.rejected_qty), 0)         AS rejected_qty,
                    COALESCE(SUM(r.hold_qty), 0)             AS hold_qty,
                    COALESCE(SUM({_PLANNED_PER_RUN_SQL}), 0) AS planned_min,
                    COALESCE(SUM({_RUN_MIN_PER_RUN_SQL}), 0) AS run_min
                FROM oee_machine_sessions s
                LEFT JOIN oee_machine_runs r
                    ON r.session_id = s.id
                   AND r.run_status = 'COMPLETED'
                WHERE s.session_date BETWEEN %s AND %s
                  AND s.machine_id = %s
                GROUP BY s.id, s.session_date, s.shift_name,
                         s.session_status, s.opened_by_name
                ORDER BY s.session_date DESC, s.shift_name, s.id
                """,
                [str(fd), str(td), row_id],
            )
            sess_rows = cur.fetchall()

            cur.execute(
                """
                SELECT
                    le.session_id                    AS session_id,
                    COALESCE(lt.loss_category, 'AR') AS loss_category,
                    SUM(le.loss_minutes)             AS total_min
                FROM oee_machine_loss_events le
                JOIN oee_machine_sessions s ON s.id = le.session_id
                LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
                WHERE s.session_date BETWEEN %s AND %s
                  AND le.machine_id = %s
                GROUP BY le.session_id, COALESCE(lt.loss_category, 'AR')
                """,
                [str(fd), str(td), row_id],
            )
            sess_loss = {}
            for lr in cur.fetchall():
                sid = lr["session_id"]
                cat = (lr["loss_category"] or "AR").upper()
                sess_loss.setdefault(sid, {"AR": 0.0, "PR": 0.0})
                sess_loss[sid][cat] = _f(lr["total_min"])

            for r in sess_rows:
                sid = r["session_id"]
                ar_l = sess_loss.get(sid, {}).get("AR", 0.0)
                pr_l = sess_loss.get(sid, {}).get("PR", 0.0)

                blk = _oee_block(
                    planned=r["planned_min"],
                    ar_loss=ar_l,
                    pr_loss=pr_l,
                    run=r["run_min"],
                    ok=r["ok_qty"],
                    rej=r["rejected_qty"],
                    hold=r["hold_qty"],
                )
                blk["session_id"]     = sid
                blk["session_date"]   = str(r["session_date"]) if r["session_date"] else ""
                blk["shift_name"]     = _shift_display(r["shift_name"])
                blk["session_status"] = r["session_status"]
                blk["opened_by_name"] = r["opened_by_name"] or ""
                blk["run_count"]      = _int(r["run_count"])
                sessions.append(blk)

            cur.execute(
                """
                SELECT
                    le.loss_code                     AS loss_code,
                    MAX(le.loss_name)                AS loss_name,
                    SUM(le.loss_minutes)             AS total_min,
                    COALESCE(lt.loss_category, 'AR') AS loss_category
                FROM oee_machine_loss_events le
                JOIN oee_machine_sessions s ON s.id = le.session_id
                LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
                WHERE s.session_date BETWEEN %s AND %s
                  AND le.machine_id = %s
                GROUP BY le.loss_code, COALESCE(lt.loss_category, 'AR')
                ORDER BY SUM(le.loss_minutes) DESC
                LIMIT 10
                """,
                [str(fd), str(td), row_id],
            )
            top_losses = [
                {
                    "loss_code":     r["loss_code"],
                    "loss_name":     r["loss_name"],
                    "loss_category": r["loss_category"],
                    "total_min":     round(_f(r["total_min"]), 2),
                }
                for r in cur.fetchall()
            ]

        else:  # operator
            cur.execute(
                f"""
                SELECT
                    s.id                                     AS session_id,
                    s.session_date                           AS session_date,
                    s.shift_name                             AS shift_name,
                    s.session_status                         AS session_status,
                    m.machine_no                             AS machine_no,
                    m.machine_name                           AS machine_name,
                    COUNT(r.id)                              AS run_count,
                    COALESCE(SUM(r.ok_qty), 0)               AS ok_qty,
                    COALESCE(SUM(r.rejected_qty), 0)         AS rejected_qty,
                    COALESCE(SUM(r.hold_qty), 0)             AS hold_qty,
                    COALESCE(SUM({_PLANNED_PER_RUN_SQL}), 0) AS planned_min,
                    COALESCE(SUM({_RUN_MIN_PER_RUN_SQL}), 0) AS run_min
                FROM oee_machine_runs r
                JOIN oee_machine_sessions s ON s.id = r.session_id
                LEFT JOIN oee_machines m    ON m.id = r.machine_id
                WHERE s.session_date BETWEEN %s AND %s
                  AND r.operator_master_id = %s
                  AND r.run_status = 'COMPLETED'
                GROUP BY s.id, s.session_date, s.shift_name,
                         s.session_status, m.machine_no, m.machine_name
                ORDER BY s.session_date DESC, s.shift_name, s.id
                """,
                [str(fd), str(td), row_id],
            )
            run_rows = cur.fetchall()

            cur.execute(
                """
                SELECT
                    le.session_id                    AS session_id,
                    COALESCE(lt.loss_category, 'AR') AS loss_category,
                    SUM(le.loss_minutes)             AS total_min
                FROM oee_machine_loss_events le
                JOIN oee_machine_sessions s ON s.id = le.session_id
                LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
                WHERE s.session_date BETWEEN %s AND %s
                  AND le.operator_master_id = %s
                GROUP BY le.session_id, COALESCE(lt.loss_category, 'AR')
                """,
                [str(fd), str(td), row_id],
            )
            loss_by_session = {}
            for lr in cur.fetchall():
                sid = lr["session_id"]
                cat = (lr["loss_category"] or "AR").upper()
                loss_by_session.setdefault(sid, {"AR": 0.0, "PR": 0.0})
                loss_by_session[sid][cat] = _f(lr["total_min"])

            for r in run_rows:
                sid = r["session_id"]
                ar_l = loss_by_session.get(sid, {}).get("AR", 0.0)
                pr_l = loss_by_session.get(sid, {}).get("PR", 0.0)

                blk = _oee_block(
                    planned=r["planned_min"],
                    ar_loss=ar_l,
                    pr_loss=pr_l,
                    run=r["run_min"],
                    ok=r["ok_qty"],
                    rej=r["rejected_qty"],
                    hold=r["hold_qty"],
                )
                blk["session_id"]     = sid
                blk["session_date"]   = str(r["session_date"]) if r["session_date"] else ""
                blk["shift_name"]     = _shift_display(r["shift_name"])
                blk["session_status"] = r["session_status"]
                blk["machine_no"]     = r["machine_no"]
                blk["machine_name"]   = r["machine_name"]
                blk["run_count"]      = _int(r["run_count"])
                sessions.append(blk)

            cur.execute(
                """
                SELECT
                    le.loss_code                     AS loss_code,
                    MAX(le.loss_name)                AS loss_name,
                    SUM(le.loss_minutes)             AS total_min,
                    COALESCE(lt.loss_category, 'AR') AS loss_category
                FROM oee_machine_loss_events le
                JOIN oee_machine_sessions s ON s.id = le.session_id
                LEFT JOIN oee_loss_types lt ON lt.loss_code = le.loss_code
                WHERE s.session_date BETWEEN %s AND %s
                  AND le.operator_master_id = %s
                GROUP BY le.loss_code, COALESCE(lt.loss_category, 'AR')
                ORDER BY SUM(le.loss_minutes) DESC
                LIMIT 10
                """,
                [str(fd), str(td), row_id],
            )
            top_losses = [
                {
                    "loss_code":     r["loss_code"],
                    "loss_name":     r["loss_name"],
                    "loss_category": r["loss_category"],
                    "total_min":     round(_f(r["total_min"]), 2),
                }
                for r in cur.fetchall()
            ]

        cur.close()
        conn.close()

        return _jsonify({
            "kind":       kind,
            "id":         row_id,
            "period":     {"from_date": str(fd), "to_date": str(td)},
            "sessions":   sessions,
            "top_losses": top_losses,
        })

    except PermissionError as exc:
        return _jsonify({"error": str(exc)}, 403)
    except Exception as exc:
        import traceback
        return _jsonify({"error": str(exc), "trace": traceback.format_exc()}, 500)